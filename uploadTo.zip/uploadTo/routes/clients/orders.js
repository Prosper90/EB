const express = require("express");
const path = require("path");
//const User = require("../model-database/users");
//const passport = require("passport");
//const LocalStrategy = require("passport-local").Strategy;
const bcrypt = require("bcrypt");
const router = express.Router();



router.get("/", checkAuthenticated, function(req, res){
  res.render("clients/orders", {user: req.user, transferAccount: undefined});
});







function checkAuthenticated(req, res, next){
    if(req.isAuthenticated()){
      return next()
    }
  
    res.redirect("/home")
  }
  






module.exports = router;